﻿using System;
public class Solution
{

	public static bool isPalindrome(int x)
	{
		int temp = x;
		int rev = 0;
		while (temp > 0)
		{
			rev = rev * 10 + temp % 10;
			temp = temp / 10;
		}

		return rev == x;
	}

	public static void Main(string[] args)
	{
		int x;
		Console.WriteLine("Enter only numbers to check palindrome:");
		x = int.Parse(Console.ReadLine());

		if (isPalindrome(x))
		{
			Console.WriteLine("True");
		}
		else
		{
			Console.WriteLine("False");
		}
	}
}

