﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionandInterface
{
    class Program
    {
        static void Main(string[] args)
        {

            ExceptionMethod();
            Console.ReadKey();
            InterfaceMethod();
            
         

        }

        private static void InterfaceMethod()
        {
            User userA = new User();
            userA.getName("John");
            userA.getAge(23);
            userA.getLocation("Toronto");
        }

        private static void ExceptionMethod()
        {
            Console.WriteLine("Enter two values");
            int[] array = new int[2];
           
            for (int i=0;i<array.Length;i++)
            {
                bool done = false;
                while(!done)
                {
                    try
                    {
                        string input = Console.ReadLine();
                        if(int.TryParse(input, out int integerinput))
                        {
                            array[i] = integerinput;
                            done = true;
                        }
                        else if (double.TryParse(input, out double doubleinput))
                            {
                            throw new NonInteger();
                        }
                        else 
                        {
                            throw new NonNumeric();
                        }
                    }

                    catch(NonNumeric nnex)
                    {
                        nnex.DisplayExceptionMessages();
                    }
                    catch(NonInteger niex)
                    {
                        niex.DisplayExceptionMessages();
                    }
                    catch(Exception ex)
                    {
                        foreach(DictionaryEntry d in ex.Data)
                        {
                            Console.WriteLine("{0} {1}", d.Key, d.Value);
                        }
                        Console.WriteLine("Helplink:", ex.HelpLink);
                    }
                }
                
            }
            Console.WriteLine("Entered values are:");
            for (int i = 0; i < array.Length; i++){
                
                Console.WriteLine(array[i]);
            }
 
        }
    }
}
