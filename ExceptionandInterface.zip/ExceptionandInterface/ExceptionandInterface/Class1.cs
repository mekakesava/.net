﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionandInterface
{
    class User:NameInterface,AgeInterface,LocationInterface
    {

        public void getName(string name)
        {
            Console.WriteLine("name is" + name);
        }
        public void getAge(int age)
        {
            Console.WriteLine("Age is" + age);
        }
        public void getLocation(string location)
        {
            Console.WriteLine("Location is" + location);
        }
       
    }
}
