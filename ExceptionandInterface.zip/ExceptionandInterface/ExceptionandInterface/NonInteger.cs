﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionandInterface
{
    class NonInteger: ApplicationException
    {
       public NonInteger()
        {
              this.HelpLink = "https://www.youtube.com/";
            this.Data.Add("Error","Entered number is not a integer value");
            this.Data.Add("Action", "Enter a number that is Integer");
        }
        public void DisplayExceptionMessages()
        {


            foreach (DictionaryEntry d in this.Data)
            {
                Console.WriteLine("{0}: {1}", d.Key, d.Value);
            }
            Console.WriteLine("The Help Link: {0}.", this.HelpLink);


        }
    }
}
