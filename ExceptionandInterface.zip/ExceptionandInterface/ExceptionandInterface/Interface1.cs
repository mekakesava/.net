﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionandInterface
{
    interface NameInterface
    {
      void getName(string name);
    }
}
