﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Task7project
{
    public delegate void mydelegate(int a, int b);

    public class mathfunction
    {

        public static void adding(int a, int b)
        {
            Console.WriteLine("addition of two numbers {0} and {1}={2}", a, b, a + b);

        }
        public static void subtract(int a, int b)
        {
            Console.WriteLine("Subtraction of two numbers {0} and {1}={2}",a,b, a - b);

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
           /* ArrayListOps();
            GenericsListOps();*/
            MyDynamicTypesGenerics();
            MyDelegateMeth();
        }
        class IndexOutOfBoundException : ApplicationException
        {
            public void displayexceptionerrormessage()
            {
                Console.WriteLine("Entered index is out of range, please enter the number in valid range ");
            }
        }
        private static void MyDelegateMeth()
        {
            Console.WriteLine("using delegate 4th method");
            mydelegate fc = new mydelegate(mathfunction.adding);
            fc(1, 2);
            fc = new mydelegate(mathfunction.subtract);
            fc(2, 1);
        }

        private static void MyDynamicTypesGenerics()
        {
            int product = sumorconcatorprod(1, 5);
            double minus = sumorconcatorprod(10.5, 3);
            string concat = sumorconcatorprod("abc", "def");
            Console.WriteLine("Multiplication of two numbers {0}", product);
            Console.WriteLine("Subraction of two numbers {0}", minus);
            Console.WriteLine("cancat of two strings {0}", concat);
        }

        private static k sumorconcatorprod<k>(k para1, k para2)
        {
            int integer;
            float floatvalue;
            bool integerres = int.TryParse(para1.ToString(), out integer);
            bool floatres = float.TryParse(para1.ToString(), out floatvalue);
            if (integerres)
            {
                return (dynamic)para1 * (dynamic)para2;
            }
            else if(floatres)
            {
                return (dynamic)para2 - (dynamic)para1;
            }
            else
            {
                return (dynamic)para2 + (dynamic)para1;
            }
        }

        private static void GenericsListOps()
        {
            string inputvalues;
            int indexvalues;
            List<string> strlist = new List<string>();
            Console.WriteLine("Enter 10 values into Generic array List and enter exit to stop");
            for (int i = 0; i < 10; i++)
            {
                inputvalues = Console.ReadLine();
                strlist.Add(inputvalues);
            }
            do
            {
                inputvalues = Console.ReadLine();
                strlist.Add(inputvalues);
            }
            while (!(inputvalues == "exit"));
            printgenericarraylist(strlist);
            do
            {
                Console.WriteLine("Enter index value in integers to delete the value");
                indexvalues = Convert.ToInt32(Console.ReadLine());
                removegenericswithindexvalue(strlist, indexvalues);
            }
            while (!(strlist.Count - 1 == 0));
        }

        private static void removegenericswithindexvalue(List<string> strlist, int indexvalues)
        {
            try
            {
                if (indexvalues > (strlist.Count - 1))
                {
                    throw new IndexOutOfBoundException();
                }
                else
                {
                    strlist.RemoveAt(indexvalues);
                    printgenericarraylist(strlist);
                }
            }
            catch (IndexOutOfBoundException ex)
            {
                ex.displayexceptionerrormessage();
            }
        }

        private static void printgenericarraylist(List<string> strlist)
        {
            if (strlist.Count > 1)
            {
                Console.WriteLine("Values are ");
                for (int i = 0; i < strlist.Count; i++)
                {
                    Console.Write(strlist[i]);
                }
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("End");
            }
        }

        private static void ArrayListOps()
        {
            string inputvalues;
            int indexvalue;
            ArrayList arrList = new ArrayList();
            Console.WriteLine("Enter 10 values into array and enter exit to stop");
            for (int i = 0; i <= 10; i++)
            {
                inputvalues = Console.ReadLine();
                arrList.Add(inputvalues);
            }
            do
            {
                inputvalues = Console.ReadLine();
                arrList.Add(inputvalues);

            }
            while (!(inputvalues == "exit"));
            printarraylist(arrList);
            do
            {
                Console.WriteLine("Enter index value in integers to delete the value");
                indexvalue = Convert.ToInt32(Console.ReadLine());
                removewithindexvalue(arrList, indexvalue);
            }
            while (!(arrList.Count - 1 == 0));

        }

        private static void printarraylist(ArrayList arrList)
        {
            if (arrList.Count > 1)
            {
                Console.WriteLine("Values are ");
                for (int i = 0; i < arrList.Count; i++)
                {
                    Console.Write(arrList[i]);
                }
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("End");
            }
        }

        private static void removewithindexvalue(ArrayList arrList, int indexvalue)
        {
            try
            {
                if (indexvalue > (arrList.Count - 1))
                {
                    throw new IndexOutOfBoundException();
                }
                else
                {
                    arrList.RemoveAt(indexvalue);
                    printarraylist(arrList);
                }
            }
            catch (IndexOutOfBoundException ex)
            {
                ex.displayexceptionerrormessage();
            }
        }

    }
}
