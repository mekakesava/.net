﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 2, 1, 3, 5, 6, 4, 8, 7, 9, 11, 10, 13, 12, 15, 14 };
            for(int i=0;i<numbers.Length; i++)
            {
                Console.WriteLine(numbers[i]);
                
               
           
            }
            Console.WriteLine("End of numbers without sorting");
            Array.Sort(numbers);
            foreach (var i in numbers) 
            {
                
                Console.WriteLine(i);
            }

            object[] obj = new object[4] { "Kesava", 25, 'M', 2000.50 };
          
            {
                Console.WriteLine("My name is {0}, I am {1},My gender is {2},i have ${3} in my account", obj[0], obj[1], obj[2],obj[3]);
            }
        }
    }
}
