﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        private static string i;
        string age, year, name;
        

        static void Main(string[] args)
        {
            method1();
            method2();
        }

        private static void method1()
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("My Name is Student");
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Title ="Hi Mom";
            Console.ReadKey();
            
        }

        private static void method2()
        {
            
            DateTime datetime = DateTime.Now;
            int year = datetime.Year;
            Console.WriteLine("enter your name");
            string name = Console.ReadLine();
            Console.WriteLine("enter your age");
            int age =int.Parse( Console.ReadLine());


           // Console.WriteLine("your name is" + name + "your age is" + age + "in the year" + year);//
            Console.WriteLine("your name is {0},your age is {1},in the year {2}", name, age, year);
          

            for (int i = age-1; i >= 0 ; i--)
            {
                year--;
                Console.WriteLine("you were {0},in the year {1}",i,year);
                
                age--;

            }


        }
    }
}
