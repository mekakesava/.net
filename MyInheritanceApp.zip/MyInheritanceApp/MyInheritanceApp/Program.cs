﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyInheritanceApp
{

    class User
    {
        public string name;
        public string location;

        
        public User() 
        {
            Console.WriteLine("Base class constructor");
        }
        public void GetUserInfo(string location)
        {
            this.location = location;
            Console.WriteLine("Name is:"+name);
            Console.WriteLine("Location is:{0}",location);

        }
    }
    class Details : User
    {
        public int age;

        public Details(int years)
        {
            this.age = years;
        }
        public int Age
        {
            set
            {
                age = value;
            }
            get
            {
                return age;
            }
        }
        public Details()
        {
            Console.WriteLine("Child class constructor");
        }
        public void GetAge()
        {
            Console.WriteLine("Age is:" + age);
        }
       

    }

    class calculate
    {
        int a, b, c;
        public void AddNumbers(int a, int b)
        {
            int sum = a + b;
            Console.WriteLine("Two numbers addition is"+ sum);

        }
        public void AddNumbers(int a, int b, int c)
        {
            int sum = a + b+c;
            Console.WriteLine("Three numbers addition is" + sum);

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Details detail = new Details();
            detail.name = "kesava";
            detail.age = 25;
            detail.GetUserInfo("India");
            detail.GetAge();

            calculate cal = new calculate();
            cal.AddNumbers(1, 2);
            cal.AddNumbers(1, 2, 3);
           
           
        }
    }
}
