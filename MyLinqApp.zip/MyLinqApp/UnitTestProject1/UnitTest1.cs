﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ConsoleApp1;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]


        [ExpectedException(typeof(DivideByZeroException), "Divide by zero attempted")]
        public void DivideZeroTest()
        {
            var test4a = new Mathops();
            var testres4a = test4a.divide(1, 0);
            Assert.AreEqual(null, testres4a, "infinite");
           
        }
        public void TestMethod1()
        {
            var test1 = new Mathops();
            var testres1 = test1.add(1, 2);
            Assert.AreEqual(3, testres1, "1+2 should be 3");
            TestMethod2();
            TestMethod3();
            TestMethod4();
            TestMethod5();
            TestMethod6();
            DivideZeroTest();
        }

        private void TestMethod6()
        {
            var test6 = new Mathops();
            var testres6 = test6.sqrt(144);
            Assert.AreEqual(12, testres6, "Squareroot of 144 should be 12");
        }

        private void TestMethod5()
        {
            var test5 = new Mathops();
            var testres5 = test5.sqr(2);
            Assert.AreEqual(4, testres5, "square of 2 should be 4");
        }

        private void TestMethod4()
        {
            var test4 = new Mathops();
            var testres4 = test4.divide(2, 2);
            Assert.AreEqual(1, testres4, "1/2 should be 1");

           
                var test4a = new Mathops();
                var testres4a = test4a.divide(1, 0);
                Assert.AreEqual(null, testres4a, "infinite");
          


        }

        private void TestMethod3()
        {
            var test3 = new Mathops();
            var testres3 = test3.multiply(3, 3);
            Assert.AreEqual(9, testres3, "3*3 should be 9");
        }

        private void TestMethod2()
        {
            var test2 = new Mathops();
            var testres2 = test2.subtract(2, 1);
            Assert.AreEqual(1, testres2, "2-1 should be 1");

        }
    }
}
