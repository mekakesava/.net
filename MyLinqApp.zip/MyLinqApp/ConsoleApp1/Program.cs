﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class point
    {
        public int x { get; set; } = 0;
        public int y { get; set; } = 0;

    }
    class Program
    {


        static void Main(string[] args)
        {
           

            IntArrayLinqOps();
            StringArrayLinqOps();
    
        }

        private static void StringArrayLinqOps()
        {
            string[] mystrings = { "canada", "usa", "australia", "pakistan", "india", "china", "argentina" };

            IEnumerable<string> query = from city in mystrings where city.StartsWith("c") select city;

            foreach (string names in query)
                Console.WriteLine("{0}", names);
        }

        private static void IntArrayLinqOps()
        {
            int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            var count = numbers.Count();
            var minvalue = numbers.Min();
            var maxvalue = numbers.Max();
            var sumvalue = numbers.Sum();
            var avgvalue = numbers.Average();
            Console.WriteLine("There are {0} elements", count);
            Console.WriteLine("Minimum value of {0} elements is {1} ", count, minvalue);
            Console.WriteLine("Maximum value of {0} elements is {1} ", count, maxvalue);
            Console.WriteLine("sum of {0} elements is {1} ", count, sumvalue);
            Console.WriteLine("Average of {0} elements is {1} ", count, avgvalue);

        }

       
        
    }

}
