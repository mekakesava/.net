﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Mathops
    {
        public int add(int x, int y) => x + y;
        public int subtract(int x, int y) => x - y;
        public int multiply(int x, int y) => x * y;
        public int divide(int x, int y) => x / y;
        public int sqr(int x) => x * x;
        public int sqrt(int x) => (int)Math.Sqrt(x);
    }
}
