﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MyFileApp
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamWriterMethod();
            BinaryWriterMethod();
        }

        private static void BinaryWriterMethod()
        {
            string Directory = "kesava";
            string filename = "binary_file.dat";
            string path = Directory + "\\" + filename;
            string[] filecontent = 
            {
                "This is the first line.",
                "This is the second line.",
                "This is the third line.",
                "This is the fourth line.",
                "This is the fifth line.",
                "This is the Last line."
            };
            FileInfo File = new FileInfo(path);
            if (!File.Exists)
            {
                BinaryWriter bw = new BinaryWriter(File.OpenWrite());

                foreach (string data in filecontent)
                    bw.Write(data);

                bw.Close();
            }

        }

        private static void StreamWriterMethod()
        {
            string Directory = "kesava";
            string filename = "stream_file.dat";
            string path = Directory + "\\" + filename;
            string[] filecontent = 
            {
                "This is the first line.",
                "This is the second line.", 
                "This is the third line.",
                "This is the fourth line.",
                "This is the fifth line.",
                "" 
            };
            FileInfo File = new FileInfo(path);
            if (!File.Exists)
            {
                StreamWriter sw = File.CreateText();

                foreach (string data in filecontent)
                    sw.WriteLine(data);

                sw.Close();
            }
        }
    }
}
